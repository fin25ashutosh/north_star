"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { OutcomeTranslator } from "./wizard-steps/outcome-translator"
import { AudienceBudget } from "./wizard-steps/audience-budget"
import { CreativeStudio } from "./wizard-steps/creative-studio"
import { WhatsAppStarter } from "./wizard-steps/whatsapp-starter"
import { PreviewPublish } from "./wizard-steps/preview-publish"

const steps = [
  { id: 1, title: "Goal", component: OutcomeTranslator },
  { id: 2, title: "Audience & Budget", component: AudienceBudget },
  { id: 3, title: "Creative", component: CreativeStudio },
  { id: 4, title: "WhatsApp", component: WhatsAppStarter },
  { id: 5, title: "Preview", component: PreviewPublish },
]

export function CampaignWizard() {
  const [currentStep, setCurrentStep] = useState(1)
  const [wizardData, setWizardData] = useState({
    goal: "",
    objective: "",
    radius: 5,
    budget: "better",
    creative: null,
    headline: "",
    whatsappLink: "",
  })

  const CurrentStepComponent = steps.find((step) => step.id === currentStep)?.component

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const updateWizardData = (data: Partial<typeof wizardData>) => {
    setWizardData((prev) => ({ ...prev, ...data }))
  }

  const progress = (currentStep / steps.length) * 100

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Progress Header */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between mb-2">
                <CardTitle className="text-lg">Create Your Campaign</CardTitle>
                <span className="text-sm text-muted-foreground">
                  Step {currentStep} of {steps.length}
                </span>
              </div>
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                {steps.map((step) => (
                  <span key={step.id} className={currentStep >= step.id ? "text-primary font-medium" : ""}>
                    {step.title}
                  </span>
                ))}
              </div>
            </CardHeader>
          </Card>

          {/* Current Step Content */}
          {CurrentStepComponent && (
            <CurrentStepComponent
              data={wizardData}
              onUpdate={updateWizardData}
              onNext={handleNext}
              onBack={handleBack}
            />
          )}

          {/* Navigation */}
          {currentStep < steps.length && (
            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={handleBack}
                disabled={currentStep === 1}
                className="flex items-center gap-2 bg-transparent"
              >
                <ChevronLeft className="h-4 w-4" />
                Back
              </Button>
              <Button
                onClick={handleNext}
                disabled={currentStep === steps.length}
                className="flex items-center gap-2 bg-primary hover:bg-primary/90"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
