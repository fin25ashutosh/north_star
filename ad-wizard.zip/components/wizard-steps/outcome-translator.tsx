"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Target } from "lucide-react"

interface OutcomeTranslatorProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onBack: () => void
}

export function OutcomeTranslator({ data, onUpdate, onNext }: OutcomeTranslatorProps) {
  const [goal, setGoal] = useState(data.goal || "")
  const [suggestedObjective, setSuggestedObjective] = useState("")

  useEffect(() => {
    if (goal.toLowerCase().includes("order") || goal.toLowerCase().includes("sale")) {
      setSuggestedObjective("Messages Campaign")
    } else if (goal.toLowerCase().includes("visit") || goal.toLowerCase().includes("customer")) {
      setSuggestedObjective("Traffic Campaign")
    } else if (goal.toLowerCase().includes("aware") || goal.toLowerCase().includes("know")) {
      setSuggestedObjective("Awareness Campaign")
    } else if (goal.trim()) {
      setSuggestedObjective("Engagement Campaign")
    } else {
      setSuggestedObjective("")
    }
  }, [goal])

  useEffect(() => {
    onUpdate({ goal, objective: suggestedObjective })
  }, [goal, suggestedObjective])

  return (
    <div className="flex justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-xl">
            <Target className="h-5 w-5 text-primary" />
            What's your goal?
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Input
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="e.g., I want more cake orders"
              className="h-12 text-base text-center"
            />
          </div>

          {suggestedObjective && (
            <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 text-center">
              <Badge variant="secondary" className="bg-primary text-primary-foreground">
                {suggestedObjective}
              </Badge>
            </div>
          )}

          <Button onClick={onNext} disabled={!goal.trim()} className="w-full h-12">
            Next
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
