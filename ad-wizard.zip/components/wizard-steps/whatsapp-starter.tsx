"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, ExternalLink, Copy } from "lucide-react"

interface WhatsAppStarterProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onBack: () => void
}

export function WhatsAppStarter({ data, onUpdate, onNext, onBack }: WhatsAppStarterProps) {
  const [whatsappLink, setWhatsappLink] = useState("")

  useEffect(() => {
    // Generate WhatsApp link based on campaign data
    const message = encodeURIComponent(
      `Hi! I'm interested in your ${data.goal || "services"}. I saw your ad and would like to know more.`,
    )
    const link = `https://wa.me/1234567890?text=${message}`
    setWhatsappLink(link)
    onUpdate({ whatsappLink: link })
  }, [data.goal, onUpdate])

  const handleTestLink = () => {
    window.open(whatsappLink, "_blank")
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(whatsappLink)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-green-600" />
          WhatsApp Order Starter
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">Generated WhatsApp Link</h3>
            <p className="text-sm text-muted-foreground mb-4">
              This link will be used in your ads to direct customers to WhatsApp for easy ordering.
            </p>
          </div>

          {/* Link Preview */}
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="bg-green-600 p-2 rounded-full">
                  <MessageCircle className="h-4 w-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-green-600 hover:bg-green-700">WhatsApp Link</Badge>
                  </div>
                  <p className="text-sm font-mono bg-white p-2 rounded border break-all">{whatsappLink}</p>
                  <p className="text-xs text-green-700 mt-2">
                    Pre-filled message: "Hi! I'm interested in your {data.goal || "services"}..."
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button onClick={handleTestLink} className="flex-1 bg-green-600 hover:bg-green-700 text-white">
              <ExternalLink className="h-4 w-4 mr-2" />
              Test Link
            </Button>
            <Button variant="outline" onClick={handleCopyLink}>
              <Copy className="h-4 w-4 mr-2" />
              Copy
            </Button>
          </div>

          {/* Preview Message */}
          <Card className="bg-muted/50">
            <CardContent className="p-4">
              <h4 className="font-medium mb-2">Message Preview</h4>
              <div className="bg-green-100 p-3 rounded-lg border-l-4 border-green-600">
                <p className="text-sm">
                  "Hi! I'm interested in your {data.goal || "services"}. I saw your ad and would like to know more."
                </p>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                This message will appear when customers click your ad
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button onClick={onNext} className="bg-primary hover:bg-primary/90">
            Next
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
