"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Eye, Rocket, AlertTriangle, Target, MapPin, DollarSign, Palette, MessageCircle } from "lucide-react"
import Link from "next/link"

interface PreviewPublishProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onBack: () => void
}

export function PreviewPublish({ data }: PreviewPublishProps) {
  const budgetLabels = {
    good: "$50/week",
    better: "$100/week",
    best: "$200/week",
  }

  const isAudienceTooSmall = data.radius < 3

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5 text-primary" />
            Campaign Preview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Campaign Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-muted/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Target className="h-4 w-4 text-primary" />
                  <span className="font-medium">Objective</span>
                </div>
                <p className="text-sm">{data.goal || "Not specified"}</p>
                {data.objective && <Badge variant="secondary">{data.objective}</Badge>}
              </CardContent>
            </Card>

            <Card className="bg-muted/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="font-medium">Audience</span>
                </div>
                <p className="text-sm">{data.radius} km radius around your business</p>
              </CardContent>
            </Card>

            <Card className="bg-muted/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-primary" />
                  <span className="font-medium">Budget</span>
                </div>
                <p className="text-sm">{budgetLabels[data.budget as keyof typeof budgetLabels] || "Not selected"}</p>
              </CardContent>
            </Card>

            <Card className="bg-muted/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Palette className="h-4 w-4 text-primary" />
                  <span className="font-medium">Creative</span>
                </div>
                <p className="text-sm">{data.headline || "No headline set"}</p>
              </CardContent>
            </Card>
          </div>

          {/* Creative Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ad Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-lg p-6 text-center">
                <div className="w-20 h-20 bg-primary/30 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Palette className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{data.headline || "Your Business Name"}</h3>
                <p className="text-muted-foreground mb-4">{data.goal || "Achieve your business goals"}</p>
                <Button className="bg-green-600 hover:bg-green-700 text-white">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Message Us
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* WhatsApp CTA */}
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <MessageCircle className="h-4 w-4 text-green-600" />
                <span className="font-medium">WhatsApp Integration</span>
              </div>
              <p className="text-sm text-green-700">
                Customers will be directed to WhatsApp with a pre-filled message about your {data.goal || "services"}.
              </p>
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      {/* Warnings */}
      {isAudienceTooSmall && (
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            Your audience radius is quite small ({data.radius} km). Consider expanding to 5+ km for better reach.
          </AlertDescription>
        </Alert>
      )}

      {/* Publish Button */}
      <Card>
        <CardContent className="p-6 text-center">
          <Link href="/dashboard">
            <Button size="lg" className="w-full max-w-md h-14 bg-primary hover:bg-primary/90 text-lg">
              <Rocket className="h-5 w-5 mr-2" />
              Publish Campaign
            </Button>
          </Link>
          <p className="text-sm text-muted-foreground mt-3">
            Your campaign will be reviewed and go live within 24 hours
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
