"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, DollarSign } from "lucide-react"

interface AudienceBudgetProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onBack: () => void
}

const budgetOptions = {
  good: { label: "Good", amount: "$50/week", leads: "5-10 leads" },
  better: { label: "Better", amount: "$100/week", leads: "15-25 leads" },
  best: { label: "Best", amount: "$200/week", leads: "30-50 leads" },
}

export function AudienceBudget({ data, onUpdate, onNext, onBack }: AudienceBudgetProps) {
  const [radius, setRadius] = useState(data.radius || 5)
  const [budget, setBudget] = useState(data.budget || "better")

  useEffect(() => {
    onUpdate({ radius, budget })
  }, [radius, budget, onUpdate])

  return (
    <div className="space-y-6">
      {/* Audience Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Target Audience
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>Radius around your business: {radius} km</Label>
            <Slider
              value={[radius]}
              onValueChange={(value) => setRadius(value[0])}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>1 km</span>
              <span>10 km</span>
            </div>
          </div>

          <div className="h-48 rounded-lg overflow-hidden border">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.9663095343008!2d-74.00425878459418!3d40.74844097932681!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a9b3117469%3A0xd134e199a405a163!2sEmpire%20State%20Building!5e0!3m2!1sen!2sus!4v1629794729807!5m2!1sen!2sus"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title={`Business location with ${radius}km radius`}
            />
          </div>
        </CardContent>
      </Card>

      {/* Budget Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            Budget Selection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(budgetOptions).map(([key, option]) => (
              <Card
                key={key}
                className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                  budget === key ? "ring-2 ring-primary bg-primary/5" : "hover:bg-accent/5"
                }`}
                onClick={() => setBudget(key)}
              >
                <CardContent className="p-4 text-center space-y-2">
                  <Badge
                    variant={budget === key ? "default" : "secondary"}
                    className={budget === key ? "bg-primary" : ""}
                  >
                    {option.label}
                  </Badge>
                  <p className="font-semibold">{option.amount}</p>
                  <p className="text-sm text-muted-foreground">{option.leads}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button onClick={onNext} className="bg-primary hover:bg-primary/90">
          Next
        </Button>
      </div>
    </div>
  )
}
