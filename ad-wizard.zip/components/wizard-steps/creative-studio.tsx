"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Upload, Palette, Type, Tag } from "lucide-react"

interface CreativeStudioProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onBack: () => void
}

export function CreativeStudio({ data, onUpdate, onNext, onBack }: CreativeStudioProps) {
  const [headline, setHeadline] = useState(data.headline || "")
  const [localLanguage, setLocalLanguage] = useState(false)
  const [stickerOverlay, setStickerOverlay] = useState(false)
  const [uploadedImage, setUploadedImage] = useState(null)

  useEffect(() => {
    onUpdate({ headline, localLanguage, stickerOverlay, creative: uploadedImage })
  }, [headline, localLanguage, stickerOverlay, uploadedImage, onUpdate])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="h-5 w-5 text-primary" />
          Creative Studio
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Upload Section */}
        <div className="space-y-4">
          <Label>Upload your logo or image</Label>
          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:bg-accent/5 transition-colors">
            <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground mb-2">Drag and drop your image here, or click to browse</p>
            <Button variant="outline" size="sm">
              Choose File
            </Button>
          </div>
        </div>

        {/* Auto-Preview */}
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Palette className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">Auto-Generated Preview</span>
            </div>
            <div className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-primary/30 rounded-full mx-auto mb-3 flex items-center justify-center">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <p className="font-semibold text-lg">{headline || "Your Headline Here"}</p>
              <div className="flex justify-center gap-2 mt-2">
                <Badge variant="secondary" className="text-xs">
                  Primary: Teal
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  Accent: Cyan
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Headline Input */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="headline" className="flex items-center gap-2">
              <Type className="h-4 w-4" />
              Headline Text
            </Label>
            <Input
              id="headline"
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              placeholder="Enter your compelling headline"
              className="h-12 text-base"
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="local-language" className="text-sm">
              Use local language
            </Label>
            <Switch id="local-language" checked={localLanguage} onCheckedChange={setLocalLanguage} />
          </div>
        </div>

        {/* Sticker Overlay */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="sticker-overlay" className="flex items-center gap-2">
              <Tag className="h-4 w-4" />
              Add price tag sticker
            </Label>
            <Switch id="sticker-overlay" checked={stickerOverlay} onCheckedChange={setStickerOverlay} />
          </div>
          {stickerOverlay && (
            <div className="pl-6">
              <Input placeholder="Enter price (e.g., $19.99)" className="max-w-xs" />
            </div>
          )}
        </div>

        {/* Back/Next navigation buttons at bottom */}
        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button onClick={onNext} className="bg-primary hover:bg-primary/90">
            Next
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
