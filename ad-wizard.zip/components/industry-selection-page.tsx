"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { Coffee, Scissors, ShoppingBag, Cake, Wrench } from "lucide-react"
import Link from "next/link"

const industries = [
  {
    id: "bakery",
    title: "Bakery",
    icon: Cake,
    description: "Cakes, pastries, and baked goods",
  },
  {
    id: "salon",
    title: "Salon",
    icon: Scissors,
    description: "Hair, beauty, and wellness services",
  },
  {
    id: "retail",
    title: "Retail",
    icon: ShoppingBag,
    description: "Products and merchandise",
  },
  {
    id: "cafe",
    title: "Café",
    icon: Coffee,
    description: "Coffee, drinks, and light meals",
  },
  {
    id: "services",
    title: "Services",
    icon: Wrench,
    description: "Professional and local services",
  },
]

export function IndustrySelectionPage() {
  const [selectedIndustry, setSelectedIndustry] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-2xl space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold text-balance">What kind of business are you?</h1>
            <p className="text-muted-foreground text-balance">
              Choose your industry to get started with targeted advertising
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {industries.map((industry) => {
              const Icon = industry.icon
              return (
                <Card
                  key={industry.id}
                  className={cn(
                    "cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-[1.02]",
                    selectedIndustry === industry.id ? "ring-2 ring-primary bg-primary/5" : "hover:bg-accent/5",
                  )}
                  onClick={() => setSelectedIndustry(industry.id)}
                >
                  <CardContent className="p-6 text-center space-y-3">
                    <div className="flex justify-center">
                      <div
                        className={cn(
                          "p-3 rounded-full transition-colors",
                          selectedIndustry === industry.id
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground",
                        )}
                      >
                        <Icon className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-semibold text-lg">{industry.title}</h3>
                      <p className="text-sm text-muted-foreground">{industry.description}</p>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="flex justify-center pt-4">
            <Link href="/wizard">
              <Button
                size="lg"
                className="w-full max-w-xs h-12 bg-primary hover:bg-primary/90 text-primary-foreground"
                disabled={!selectedIndustry}
              >
                Continue
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
