"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Mail, Chrome } from "lucide-react"
import Link from "next/link"

export function LoginPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center space-y-2">
          <CardTitle className="text-2xl font-bold text-balance">Welcome to Ad Wizard</CardTitle>
          <CardDescription className="text-muted-foreground text-balance">
            Launch your first ad in 5 minutes.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Link href="/industry">
            <Button className="w-full h-11 bg-primary hover:bg-primary/90 text-primary-foreground" size="lg">
              <Chrome className="mr-2 h-4 w-4" />
              Login with Google
            </Button>
          </Link>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <Separator className="w-full" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">Or</span>
            </div>
          </div>

          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="Enter your email" className="h-11" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" placeholder="Enter your password" className="h-11" />
            </div>
            <Link href="/industry">
              <Button className="w-full h-11 bg-accent hover:bg-accent/90 text-accent-foreground" size="lg">
                <Mail className="mr-2 h-4 w-4" />
                Login with Email
              </Button>
            </Link>
          </div>

          <div className="text-center text-sm text-muted-foreground">
            Don't have an account? <button className="text-primary hover:underline font-medium">Sign up</button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
