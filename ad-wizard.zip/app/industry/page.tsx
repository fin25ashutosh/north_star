import { IndustrySelectionPage } from "@/components/industry-selection-page"

export default function Industry() {
  return <IndustrySelectionPage />
}
