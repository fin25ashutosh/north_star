import { CampaignWizard } from "@/components/campaign-wizard"

export default function Wizard() {
  return <CampaignWizard />
}
