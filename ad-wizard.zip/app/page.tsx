import { LoginPage } from "@/components/login-page"

export default function Home() {
  return <LoginPage />
}
